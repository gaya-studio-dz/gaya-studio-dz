GAYA STUDIO ⵣ — GitHub Pages static demo

Upload index.html to a public GitHub repository. Settings > Pages > Deploy from a branch > main / (root).

This demo uses the local template generator only. It does not run the Node.js AI API, authentication or payments.
